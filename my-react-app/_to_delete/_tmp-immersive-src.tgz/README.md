# Pro Coder

Pro Coder is a free learning arcade for children under 12, built with React and
Vite. Games are open to everyone (no sign-in); progress and XP are saved on the
device, and optionally to a free account. Every game works in English and Bangla.

| Game | Route | Practises |
|------|-------|-----------|
| Math Hero | `/games/math-hero` | addition and subtraction against the clock |
| Memory Match | `/games/memory-match` | memory, then matching pictures to written words |
| Pattern Quest | `/games/pattern-quest` | number and shape patterns, quick sums |
| Math Master (12+) | `/games/math-master` | 3D maths lab: 10 levels, 100 verified questions from number sense to multi-step algebra, geometry and probability |

To add a game, see [`src/games/README.md`](src/games/README.md).

**HTML Course** (`/quiz/`): a 70-question, 10-level HTML course (fundamentals → forms, semantic
HTML, metadata and accessibility), each question with a hint and a mini-lesson. The page is
`quiz/index.html` + `quiz/engine.js`; the curriculum and questions live in `src/courses/`, so CSS
and JavaScript courses can be added later and played by the same engine (`/quiz/?course=<id>`).
See [`src/courses/README.md`](src/courses/README.md).

> The product was renamed from Bulbuli to **Pro Coder**. Bulbuli is still the name of the bird
> mascot in the games. The domain (`bulbuli.org`), localStorage keys and asset file names keep
> their old names so links and saved progress keep working.

**3D Game Studio** (`/game`): VoxelCraft, a build-and-play voxel level studio for older players,
lives in its own feature folder. See [3D Game Studio (VoxelCraft)](#3d-game-studio-voxelcraft).

## Home page and navigation

The home page shows one zone at a time: **Play & Learn** or **Build & Create**, picked with the
mode slider in the header (`src/arcade/ModeToggle.jsx`; the choice is saved as `bulbuli.home.mode`).
The 3D Game Studio (`/game`) opens from its card in Build & Create, and Pro Coder (the HTML course)
sits there too. The header (`src/arcade/ArcadeHeader.jsx`) shows the brand, the mode slider, the language switch,
and the profile button (Sign in, or the player's avatar linking to `/dashboard`). On a game page
the navigation becomes a big "All games" button, and sound and day/night join the controls.

The category and an open launcher game live in the address (`src/arcade/zone.js`):

| Address | Shows |
|---------|-------|
| `/` | Educational games (the default) |
| `/?category=adventure` | Adventure games |
| `/?category=adventure&play=<id>` | that game open in the launcher |
| `/games/<id>` | a game on its own page |
| `/dashboard` | a signed-in player's level, XP and per-game activity |
| `/game` | the 3D Game Studio (VoxelCraft), full page |

Old Learn, course, exam and grammar links (`/?zone=learn`, `/tutorials/…`, `/grammar/…`) land on
the games.

## Saved progress and accounts

Progress is kept per player on the device by `useGameProgress(playerId)`
(`src/hooks/useGameProgress.js`): each game's record, Math Hero's run, and total XP. Signing in is
optional; signed-in players' XP is also saved to their Supabase profile (`src/lib/xp.js`, the
`award_xp()` function in `supabase/migrations/`), and `/dashboard` shows it.

## Math Hero ad card

`/share/math-hero` shows a shareable Math Hero advert (`src/promo/MathHeroAdCard.jsx`).
**Download & Share** saves a 1080 × 1350 PNG (`ProCoder-MathHero-Ad.png`); on phones and
tablets it opens the share sheet instead (Web Share API), with **Save image only** as a
fallback. The PNG is painted on a canvas from the same layout as the card
(`src/promo/adContent.js`), so change text, colours or positions there.

On the live card, tap Math Hero, his speech bubble or the **Listen** button and he reads his
message aloud in Bengali (`src/promo/adVoice.js`): `window.speechSynthesis` with a `bn-BD` voice,
then any `bn` voice; on devices with no Bengali voice (most Windows PCs, iPhones, iPads) the same
online Bangla voice as the Math Hero game. It respects the arcade's mute switch. The **Play Now**
button links to `/games/math-hero` (pass a full URL as `to` to link elsewhere).

The downloaded PNG can't talk or be clicked, so instead of the button it prints a panel with
`bulbuli.org` and a QR code that opens `https://bulbuli.org/games/math-hero`
(`src/promo/qrMathHero.js`; make a new code there if the address changes).

### Share with Friends

Under the card there is one button, **Share with Friends** (`shareLink` in
`src/promo/MathHeroAdCard.jsx`). It opens the phone's or computer's share sheet
(`navigator.share`) with:

- title: `Math Hero on Pro Coder`
- text: `Hey Explorer! 🚀 Play Math Hero with me for free on Pro Coder!`
- url: `https://bulbuli.org/share/math-hero`

(Bangla title and text when the page is in Bangla; see `src/promo/adContent.js` and
`src/promo/shareData.js`.) Where sharing isn't available, as in many desktop browsers, it copies
the link to the clipboard; if that is blocked too, it shows the link to copy by hand.

The landing page `/share/math-hero` plays a word-by-word intro straight away, and Math Hero speaks
on the first tap. `share/math-hero/index.html` gives the shared link a Math Hero preview in chat
apps (built as a second page in `vite.config.js`).

Earlier export options (talking video, animated GIF and picture) are no longer shown. Their code
is unused and can be deleted: `renderAdVideo.js`, `videoTimeline.js` (+ test),
`public/audio/math-hero-ad-bn.mp3`, `renderAdGif.js`, `gifEncoder.js` (+ test), `gifTimeline.js`,
`fileLinks.js`, and `renderAdCardBlob` / `buildVideoShareData`.

## Shared answer feedback (Math Hero)

Math Hero builds its question card from reusable feedback pieces:

```jsx
import AnimatedAnswerOption from './components/AnimatedAnswerOption.jsx'
import AnimatedQuizCard from './components/AnimatedQuizCard.jsx'
import LifeCounter from './components/LifeCounter.jsx'
import MilestoneBanner from './components/MilestoneBanner.jsx'
import useQuizFeedback from './hooks/useQuizFeedback.js'

const { feedback, milestone, triggerCorrect, triggerWrong, triggerBonus } = useQuizFeedback()
```

Pass `feedback` to the animated card and answer options; use the life counter and milestone
banner for game events. The hook also exposes `triggerClick`, `triggerLevelUp` and
`triggerGameOver`. Sound and animation timings/colours live in `src/utils/sound.js` and
`src/utils/feedbackConfig.js`.

## 3D Game Studio (VoxelCraft)

`src/features/voxelcraft/` holds the whole game: React Three Fiber viewport, platformer physics,
community gallery, contests, profile and shop. `src/App.jsx` mounts its entry component,
`VoxelCraftStudio`, at `/game` (lazily, so three.js loads only there), and its "‹ Pro Coder" link
navigates back. Details: [`src/features/voxelcraft/README.md`](src/features/voxelcraft/README.md).

It's isolated from the rest of Pro Coder:

- **State:** its providers live inside `VoxelCraftStudio`; no Pro Coder context is used or changed.
- **Storage:** every key starts with `bulbuli_voxelcraft_` (`state/storageKeys.js`).
- **Styles:** the game uses Tailwind, Pro Coder doesn't. Its CSS is precompiled into
  `styles/voxelcraft.css` with every rule scoped to `#voxelcraft-root`, so it can't change the
  arcade, and the arcade's global `button` / `a` / heading styles can't change the game. After
  editing the game's Tailwind classes, run `npm run build:voxelcraft-css`.

## Development

```sh
npm install
npm run dev
```

## Validate

```sh
npm run lint
npm test
npm run build   # dist/ should contain share/math-hero/index.html too
npm run check:voxelcraft-levels   # optional, slow: every built-in VoxelCraft level is beatable
```
