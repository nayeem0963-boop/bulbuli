import { DraftingCompass, Parentheses, Percent, Scale, Variable } from 'lucide-react'

/** Each level's icon (by `level.icon` in engine.js). */
export const LEVEL_ICONS = { order: Parentheses, percent: Percent, ratio: Scale, algebra: Variable, geometry: DraftingCompass }

/**
 * Each level's accent colour as whole Tailwind class names (Tailwind only finds classes written out
 * in full, so these can't be built from strings like `text-${accent}-300`).
 */
export const ACCENTS = {
  sky: {
    text: 'text-sky-300',
    chip: 'bg-sky-400/15 text-sky-200 ring-sky-400/40',
    ring: 'border-sky-400/40 hover:border-sky-300/80',
    glow: 'shadow-[0_0_34px_-10px_rgba(56,189,248,0.7)]',
    bar: 'from-sky-400 to-cyan-300',
  },
  violet: {
    text: 'text-violet-300',
    chip: 'bg-violet-400/15 text-violet-200 ring-violet-400/40',
    ring: 'border-violet-400/40 hover:border-violet-300/80',
    glow: 'shadow-[0_0_34px_-10px_rgba(167,139,250,0.75)]',
    bar: 'from-violet-400 to-fuchsia-300',
  },
  emerald: {
    text: 'text-emerald-300',
    chip: 'bg-emerald-400/15 text-emerald-200 ring-emerald-400/40',
    ring: 'border-emerald-400/40 hover:border-emerald-300/80',
    glow: 'shadow-[0_0_34px_-10px_rgba(52,211,153,0.7)]',
    bar: 'from-emerald-400 to-teal-300',
  },
  rose: {
    text: 'text-rose-300',
    chip: 'bg-rose-400/15 text-rose-200 ring-rose-400/40',
    ring: 'border-rose-400/40 hover:border-rose-300/80',
    glow: 'shadow-[0_0_34px_-10px_rgba(251,113,133,0.7)]',
    bar: 'from-rose-400 to-pink-300',
  },
  amber: {
    text: 'text-amber-300',
    chip: 'bg-amber-400/15 text-amber-200 ring-amber-400/40',
    ring: 'border-amber-400/40 hover:border-amber-300/80',
    glow: 'shadow-[0_0_34px_-10px_rgba(251,191,36,0.75)]',
    bar: 'from-amber-400 to-yellow-200',
  },
}

/** The gold "go" button used for every main action. */
export const GOLD_BUTTON =
  'inline-flex min-h-14 cursor-pointer items-center justify-center gap-2 rounded-2xl border-0 bg-gradient-to-b from-yellow-300 to-amber-400 px-6 font-hero text-lg font-extrabold text-[#0B0F19] shadow-[0_0_28px_-6px_rgba(250,204,21,0.8),inset_0_-3px_0_rgba(0,0,0,0.18)] transition duration-150 hover:-translate-y-0.5 hover:brightness-105 active:translate-y-0.5 active:shadow-[0_0_16px_-6px_rgba(250,204,21,0.8)] focus-visible:outline-3 focus-visible:outline-offset-3 focus-visible:outline-yellow-200'

/** The quiet outlined button next to it. */
export const GHOST_BUTTON =
  'inline-flex min-h-14 cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-slate-600 bg-slate-800/60 px-5 font-hero text-lg font-bold text-slate-100 transition duration-150 hover:border-slate-400 hover:bg-slate-700/70 active:translate-y-0.5 focus-visible:outline-3 focus-visible:outline-offset-3 focus-visible:outline-yellow-200'

/** The glowing slate card every screen is built from. */
export const CARD = 'rounded-3xl border border-slate-700/80 bg-slate-900/70 backdrop-blur-sm'
