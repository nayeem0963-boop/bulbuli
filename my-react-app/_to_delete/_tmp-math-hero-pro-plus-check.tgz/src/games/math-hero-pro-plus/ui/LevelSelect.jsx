import { Link } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Lock, Play, RotateCcw, Zap } from 'lucide-react'
import { bestStars, isUnlocked, LEVELS } from '../engine.js'
import { StarRow } from './Celebrate.jsx'
import { ACCENTS, CARD, LEVEL_ICONS } from './theme.js'

const LADDER_LINK =
  'inline-flex items-center gap-1 font-bold text-sky-300 underline-offset-4 hover:text-sky-200 hover:underline focus-visible:outline-2 focus-visible:outline-yellow-200'

function LevelCard({ level, record, suggested, language, text, n, onOpen }) {
  const open = isUnlocked(level.id, record)
  const stars = bestStars(record, level.id)
  const played = (record.levels?.[level.id]?.plays ?? 0) > 0
  const accent = ACCENTS[level.accent]
  const Icon = LEVEL_ICONS[level.icon]
  const isNext = open && suggested

  return (
    <li className="list-none">
      <button
        type="button"
        disabled={!open}
        onClick={() => onOpen(level.id)}
        aria-label={`${text.levelN(n(level.id))}: ${level.title[language]}. ${open ? text.starsOf(n(stars), n(3)) : `${text.locked}. ${text.unlockHint(n(level.id - 1))}`}`}
        className={`group relative flex h-full w-full flex-col gap-3 overflow-hidden p-5 text-left transition duration-200 ${CARD} border-2 ${
          open
            ? `cursor-pointer ${accent.ring} ${isNext ? accent.glow : ''} hover:-translate-y-1 active:translate-y-0 focus-visible:outline-3 focus-visible:outline-offset-3 focus-visible:outline-yellow-200`
            : 'cursor-not-allowed border-slate-800 opacity-60 grayscale-[0.6]'
        }`}
      >
        {isNext && (
          <span className="absolute top-4 right-4 rounded-full bg-amber-300 px-2.5 py-0.5 text-xs font-extrabold text-[#0B0F19] mhpp-anim-glow">
            {text.suggested}
          </span>
        )}
        <span className={`grid size-14 place-items-center rounded-2xl ring-1 ${open ? accent.chip : 'bg-slate-800 text-slate-500 ring-slate-700'}`}>
          {open ? <Icon size={30} strokeWidth={2.75} aria-hidden="true" focusable="false" /> : <Lock size={26} strokeWidth={2.5} aria-hidden="true" focusable="false" />}
        </span>
        <span className="flex flex-col gap-1">
          <span className={`text-xs font-extrabold tracking-widest uppercase ${open ? accent.text : 'text-slate-500'}`}>{text.levelN(n(level.id))}</span>
          <span className="font-hero text-xl leading-tight font-extrabold text-white">{level.title[language]}</span>
          <span className="text-sm text-slate-300">{level.blurb[language]}</span>
        </span>
        <span className="mt-auto flex flex-wrap items-center justify-between gap-2 pt-2">
          <StarRow stars={stars} size={22} />
          <span className="inline-flex items-center gap-1 text-xs font-bold text-yellow-200/90">
            <Zap size={14} strokeWidth={2.75} aria-hidden="true" focusable="false" />
            {text.upToXp(n(level.maxXp))}
          </span>
        </span>
        <span
          className={`flex min-h-12 items-center justify-center gap-2 rounded-xl font-hero text-base font-extrabold transition ${
            open
              ? 'bg-amber-300 text-[#0B0F19] group-hover:bg-yellow-200'
              : 'bg-slate-800 text-slate-400'
          }`}
          aria-hidden="true"
        >
          {open ? (
            <>
              {played ? <RotateCcw size={18} strokeWidth={3} /> : <Play size={18} strokeWidth={3} className="fill-current" />}
              {played ? text.replay : text.start}
            </>
          ) : (
            <>
              <Lock size={16} strokeWidth={3} />
              {text.unlockHint(n(level.id - 1))}
            </>
          )}
        </span>
      </button>
    </li>
  )
}

function BadgeShelf({ record, language, text }) {
  const won = new Set(record.badges ?? [])
  return (
    <section className={`mt-6 p-5 ${CARD}`} aria-labelledby="mhpp-badges-heading">
      <h3 id="mhpp-badges-heading" className="m-0 mb-3 font-hero text-lg font-extrabold text-white">{text.collection}</h3>
      {won.size === 0 && <p className="m-0 mb-3 text-sm text-slate-400">{text.collectionEmpty}</p>}
      <ul className="m-0 grid grid-cols-2 gap-3 p-0 @lg:grid-cols-3 @3xl:grid-cols-5">
        {LEVELS.map((level) => {
          const has = won.has(level.badge.id)
          return (
            <li
              key={level.id}
              className={`flex list-none items-center gap-2.5 rounded-2xl border px-3 py-2.5 ${
                has ? 'border-amber-300/50 bg-amber-300/10 shadow-[0_0_22px_-10px_rgba(250,204,21,0.9)]' : 'border-slate-700 bg-slate-800/50'
              }`}
            >
              <span className={`text-2xl ${has ? '' : 'opacity-40 grayscale'}`} aria-hidden="true">{level.badge.emoji}</span>
              <span className={`text-sm leading-tight font-bold ${has ? 'text-amber-100' : 'text-slate-500'}`}>
                {has ? level.badge.name[language] : '???'}
                <span className="sr-only">{has ? '' : ` — ${text.badgeLocked}`}</span>
              </span>
            </li>
          )
        })}
      </ul>
    </section>
  )
}

export default function LevelSelect({ record, suggested, language, text, n, onOpen, headingRef }) {
  return (
    <section aria-labelledby="mhpp-levels-heading" className="relative z-10">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 id="mhpp-levels-heading" ref={headingRef} tabIndex={-1} className="m-0 font-hero text-2xl font-extrabold text-white outline-none @xl:text-3xl">
            {text.pickMission}
          </h2>
          <p className="m-0 mt-1 text-sm text-slate-400">{text.pickMissionHint}</p>
        </div>
      </div>
      <ol className="m-0 grid grid-cols-1 gap-4 p-0 @lg:grid-cols-2 @4xl:grid-cols-3 @6xl:grid-cols-5">
        {LEVELS.map((level) => (
          <LevelCard
            key={level.id}
            level={level}
            record={record}
            suggested={level.id === suggested}
            language={language}
            text={text}
            n={n}
            onOpen={onOpen}
          />
        ))}
      </ol>
      <BadgeShelf record={record} language={language} text={text} />
      {/* the ladder: Math Hero Pro (6–11) → Math Hero Pro+ (10–12) → Math Master (12+) */}
      <div className="m-0 mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-center text-sm text-slate-400">
        <p className="m-0 flex flex-wrap items-center justify-center gap-x-2">
          {text.youngerKids}
          <Link to="/games/math-hero-pro" className={LADDER_LINK}>
            <ArrowLeft size={14} strokeWidth={3} aria-hidden="true" focusable="false" />
            {text.youngerKidsLink}
          </Link>
        </p>
        <p className="m-0 flex flex-wrap items-center justify-center gap-x-2">
          {text.olderKids}
          <Link to="/games/math-master" className={LADDER_LINK}>
            {text.olderKidsLink}
            <ArrowRight size={14} strokeWidth={3} aria-hidden="true" focusable="false" />
          </Link>
        </p>
      </div>
    </section>
  )
}
