import { Award, Sparkles, Star, Zap } from 'lucide-react'
import { GameFullscreenButton } from '../../../arcade/GameFullscreen.jsx'
import { MAX_STARS, totalStars } from '../engine.js'

const TOOL_BUTTON =
  'grid size-12 cursor-pointer place-items-center rounded-2xl border border-slate-600 bg-slate-800/70 p-0 text-slate-100 transition hover:border-amber-300/70 hover:text-amber-200 focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-yellow-200'

function Stat({ icon: Icon, label, value, tone }) {
  return (
    <div className="flex min-w-0 items-center gap-2 rounded-2xl border border-slate-700/80 bg-slate-900/70 px-3 py-2">
      <Icon size={20} strokeWidth={2.5} aria-hidden="true" focusable="false" className={tone} />
      <dl className="m-0 min-w-0">
        <dt className="text-[0.7rem] font-bold tracking-wider text-slate-400 uppercase">{label}</dt>
        <dd className="m-0 font-hero text-lg leading-tight font-extrabold text-white">{value}</dd>
      </dl>
    </div>
  )
}

export default function Header({ record, totalXp, compact, text, n }) {
  const badgeCount = record.badges?.length ?? 0
  return (
    <header className={`relative z-10 flex flex-wrap items-center justify-between gap-x-6 gap-y-4 ${compact ? 'mb-3' : 'mb-6'}`}>
      <div className="flex min-w-0 items-center gap-3">
        <span
          aria-hidden="true"
          className={`grid shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-yellow-300 to-amber-500 text-[#0B0F19] shadow-[0_0_30px_-4px_rgba(250,204,21,0.7)] ${compact ? 'size-11' : 'size-14 @xl:size-16'}`}
        >
          <Zap size={compact ? 24 : 32} strokeWidth={2.75} className="fill-[#0B0F19]/15" />
        </span>
        <div className="min-w-0">
          {!compact && (
            <div className="mb-1 flex flex-wrap gap-1.5">
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-300/15 px-2.5 py-0.5 text-xs font-extrabold tracking-wide text-amber-200 ring-1 ring-amber-300/40">
                <Sparkles size={12} strokeWidth={3} aria-hidden="true" focusable="false" />
                {text.zone}
              </span>
              <span className="rounded-full bg-sky-400/15 px-2.5 py-0.5 text-xs font-extrabold tracking-wide text-sky-200 ring-1 ring-sky-400/40">
                {text.ages}
              </span>
            </div>
          )}
          <h1 className={`m-0 font-hero leading-none font-extrabold text-white ${compact ? 'text-2xl' : 'text-4xl @xl:text-5xl'}`}>
            {text.title}
          </h1>
          {!compact && <p className="m-0 mt-1.5 max-w-[46ch] text-sm text-slate-300 @xl:text-base">{text.tagline}</p>}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {!compact && (
          <>
            <Stat icon={Star} label={text.stars} value={`${n(totalStars(record))} / ${n(MAX_STARS)}`} tone="fill-amber-300 text-amber-300" />
            <Stat icon={Zap} label={text.xp} value={n(totalXp)} tone="text-yellow-300" />
            <Stat icon={Award} label={text.badges} value={`${n(badgeCount)} / ${n(5)}`} tone="text-fuchsia-300" />
          </>
        )}
        <GameFullscreenButton className={TOOL_BUTTON} iconSize={20} />
      </div>
    </header>
  )
}
