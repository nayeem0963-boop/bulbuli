/**
 * The pictures on a Math Hero Pro+ question card. Each `visual.kind` from questions.js has one drawing here:
 *
 *   balance   an equation as a balance scale (Level 4)
 *   tape      a ratio as bars of equal parts (Level 3)
 *   rect      a rectangle or square with labelled sides (Level 5)
 *   triangle  a triangle with its known angles and a "?" (general, right-angled or isosceles)
 *   triArea   a triangle with its base and dashed height
 *   quad      a quadrilateral with three known angles
 *   lshape    a rectangle with a corner cut out
 *
 * They're decoration for sighted players: the question text and equation always carry everything
 * needed, so the whole picture is hidden from screen readers (aria-hidden).
 */

const SVG_CLASS = 'h-36 w-auto max-w-full @xl:h-44 xl:h-52'
const LABEL = 'fill-slate-100 font-hero text-[15px] font-extrabold'
const UNKNOWN = 'fill-amber-300 font-hero text-[17px] font-extrabold'
const SHAPE = 'fill-sky-400/10 stroke-sky-300'

const angleText = (value, n) => (value === null ? '?' : `${n(value)}°`)

/** A point `dist` px from vertex `p` towards point `toward`. */
function inward(p, toward, dist) {
  const dx = toward[0] - p[0]
  const dy = toward[1] - p[1]
  const len = Math.hypot(dx, dy) || 1
  return [p[0] + (dx / len) * dist, p[1] + (dy / len) * dist]
}
const centroid = (points) => [
  points.reduce((s, p) => s + p[0], 0) / points.length,
  points.reduce((s, p) => s + p[1], 0) / points.length,
]

/** Angle labels just inside each corner; the unknown one gets a soft gold halo. */
function AngleLabels({ points, angles, n }) {
  const c = centroid(points)
  return points.map((p, i) => {
    const [x, y] = inward(p, c, 34)
    const value = angles[i]
    return (
      <g key={i}>
        {value === null && <circle cx={x} cy={y - 5} r="14" className="fill-amber-300/15 stroke-amber-300/60" strokeWidth="1.5" />}
        <text x={x} y={y} textAnchor="middle" className={value === null ? UNKNOWN : LABEL}>{angleText(value, n)}</text>
      </g>
    )
  })
}

const pointsAttr = (points) => points.map((p) => p.join(',')).join(' ')

// ---------- Level 4 ----------

function Balance({ left, right, n }) {
  const pan = (cx, label) => (
    <g>
      <path d={`M${cx} 46 L${cx - 40} 92 M${cx} 46 L${cx + 40} 92`} className="stroke-slate-500" strokeWidth="2" />
      <path d={`M${cx - 54} 92 Q${cx} 120 ${cx + 54} 92 Z`} className="fill-slate-700 stroke-slate-500" strokeWidth="2" />
      <rect x={cx - 52} y="60" width="104" height="30" rx="9" className="fill-slate-900 stroke-amber-300/70" strokeWidth="2" />
      <text x={cx} y="81" textAnchor="middle" className="fill-amber-100 font-hero text-[18px] font-extrabold">{n(label)}</text>
    </g>
  )
  return (
    <svg viewBox="0 0 300 160" className={SVG_CLASS}>
      <path d="M150 46 L132 148 H168 Z" className="fill-slate-700 stroke-slate-500" strokeWidth="2" strokeLinejoin="round" />
      <rect x="116" y="146" width="68" height="8" rx="4" className="fill-slate-600" />
      <path d="M62 46 H238" className="stroke-amber-300" strokeWidth="5" strokeLinecap="round" />
      <circle cx="150" cy="46" r="7" className="fill-amber-300" />
      {pan(62, left)}
      {pan(238, right)}
      <text x="150" y="30" textAnchor="middle" className="fill-emerald-300 font-hero text-[22px] font-extrabold">=</text>
    </svg>
  )
}

// ---------- Level 3 ----------

const TONES = {
  sky: { box: 'border-sky-300 bg-sky-400/25', text: 'text-sky-200' },
  amber: { box: 'border-amber-300 bg-amber-300/25', text: 'text-amber-200' },
  rose: { box: 'border-rose-300 bg-rose-400/25', text: 'text-rose-200' },
}

function Tape({ parts, labels, tones = ['sky', 'amber'], language, n }) {
  return (
    <div className="grid w-full max-w-md grid-cols-[auto_1fr] items-center gap-x-3 gap-y-2.5">
      {parts.map((count, row) => {
        const tone = TONES[tones[row]] ?? TONES.sky
        return [
          <span key={`l${row}`} className={`text-right text-sm font-extrabold tracking-wide uppercase ${tone.text}`}>
            {labels[row][language] ?? labels[row].en} <span className="text-slate-400">({n(count)})</span>
          </span>,
          <span key={`b${row}`} className="flex flex-wrap gap-1.5">
            {Array.from({ length: count }, (_, i) => (
              <span key={i} className={`grid size-9 place-items-center rounded-lg border-2 font-hero text-base font-extrabold text-white xl:size-11 ${tone.box}`}>?</span>
            ))}
          </span>,
        ]
      })}
    </div>
  )
}

// ---------- Level 5 ----------

function Rect({ w, h, unit, area, perimeter, square, n }) {
  const [x, y, W, H] = square ? [80, 18, 116, 116] : [44, 22, 190, 106]
  const label = (value) => (value === '?' ? '?' : `${n(value)} ${unit}`)
  const centre = area ?? perimeter
  return (
    <svg viewBox="0 0 290 170" className={SVG_CLASS}>
      <rect x={x} y={y} width={W} height={H} className={SHAPE} strokeWidth="3" />
      {/* little right-angle marks in two corners */}
      <path d={`M${x} ${y + 14} h14 v-14`} className="fill-none stroke-sky-300/70" strokeWidth="1.5" />
      <path d={`M${x + W - 14} ${y + H} v-14 h14`} className="fill-none stroke-sky-300/70" strokeWidth="1.5" />
      <text x={x + W / 2} y={y + H + 24} textAnchor="middle" className={w === '?' ? UNKNOWN : LABEL}>{label(w)}</text>
      <text x={x + W + 10} y={y + H / 2 + 5} textAnchor="start" className={h === '?' ? UNKNOWN : LABEL}>{label(h)}</text>
      {centre && <text x={x + W / 2} y={y + H / 2 + 6} textAnchor="middle" className="fill-sky-200 font-hero text-[16px] font-extrabold">{n(centre)}</text>}
    </svg>
  )
}

function Triangle({ angles, right = false, isosceles = false, n }) {
  let points
  if (right) points = [[48, 146], [250, 146], [48, 22]]
  else if (isosceles) points = [[150, 18], [44, 146], [256, 146]]
  else points = [[36, 146], [252, 146], [176, 22]]
  return (
    <svg viewBox="0 0 290 166" className={SVG_CLASS}>
      <polygon points={pointsAttr(points)} className={SHAPE} strokeWidth="3" strokeLinejoin="round" />
      {right && <path d="M48 128 h18 v18" className="fill-none stroke-amber-300" strokeWidth="2.5" />}
      {isosceles && (
        <g className="stroke-amber-300" strokeWidth="3" strokeLinecap="round">
          <path d="M90 76 L103 86" />
          <path d="M210 76 L197 86" />
        </g>
      )}
      <AngleLabels points={points} angles={angles} n={n} />
    </svg>
  )
}

function TriArea({ base, height, unit, n }) {
  const points = [[34, 140], [250, 140], [150, 20]]
  return (
    <svg viewBox="0 0 300 172" className={SVG_CLASS}>
      <polygon points={pointsAttr(points)} className={SHAPE} strokeWidth="3" strokeLinejoin="round" />
      <path d="M150 20 V140" className="stroke-amber-300" strokeWidth="2.5" strokeDasharray="6 5" />
      <path d="M150 126 h14 v14" className="fill-none stroke-amber-300" strokeWidth="2" />
      <text x="142" y="88" textAnchor="end" className="fill-amber-200 font-hero text-[15px] font-extrabold">{`${n(height)} ${unit}`}</text>
      <text x="142" y="164" textAnchor="middle" className={LABEL}>{`${n(base)} ${unit}`}</text>
    </svg>
  )
}

function Quad({ angles, n }) {
  const points = [[34, 140], [252, 150], [228, 30], [82, 18]]
  return (
    <svg viewBox="0 0 290 168" className={SVG_CLASS}>
      <polygon points={pointsAttr(points)} className={SHAPE} strokeWidth="3" strokeLinejoin="round" />
      <AngleLabels points={points} angles={angles} n={n} />
    </svg>
  )
}

function LShape({ W, H, w, h, unit, n }) {
  const [x0, y0, maxW, maxH] = [62, 28, 170, 120]
  const s = Math.min(maxW / W, maxH / H)
  const [right, bottom] = [x0 + W * s, y0 + H * s]
  const notchX = x0 + (W - w) * s
  const notchY = y0 + h * s
  const path = `M${x0} ${y0} H${notchX} V${notchY} H${right} V${bottom} H${x0} Z`
  const label = (v) => `${n(v)} ${unit}`
  return (
    <svg viewBox="0 0 300 186" className={SVG_CLASS}>
      <rect x={notchX} y={y0} width={w * s} height={h * s} className="fill-none stroke-slate-500" strokeWidth="2" strokeDasharray="5 5" />
      <path d={path} className={SHAPE} strokeWidth="3" strokeLinejoin="round" />
      <text x={(x0 + right) / 2} y={bottom + 22} textAnchor="middle" className={LABEL}>{label(W)}</text>
      <text x={x0 - 8} y={(y0 + bottom) / 2 + 5} textAnchor="end" className={LABEL}>{label(H)}</text>
      <text x={notchX + (w * s) / 2} y={y0 - 8} textAnchor="middle" className="fill-slate-300 font-hero text-[14px] font-bold">{label(w)}</text>
      <text x={right + 6} y={y0 + (h * s) / 2 + 5} textAnchor="start" className="fill-slate-300 font-hero text-[14px] font-bold">{label(h)}</text>
    </svg>
  )
}

const GEOMETRY = new Set(['rect', 'triangle', 'triArea', 'quad', 'lshape'])

export default function Visual({ visual, n, language, text }) {
  if (!visual) return null
  const body = {
    balance: () => <Balance {...visual} n={n} />,
    tape: () => <Tape {...visual} language={language} n={n} />,
    rect: () => <Rect {...visual} n={n} />,
    triangle: () => <Triangle {...visual} n={n} />,
    triArea: () => <TriArea {...visual} n={n} />,
    quad: () => <Quad {...visual} n={n} />,
    lshape: () => <LShape {...visual} n={n} />,
  }[visual.kind]
  if (!body) return null
  return (
    <div className="flex w-full flex-col items-center gap-1 py-2" aria-hidden="true">
      {body()}
      {GEOMETRY.has(visual.kind) && <span className="text-xs text-slate-500">{text.notToScale}</span>}
    </div>
  )
}
