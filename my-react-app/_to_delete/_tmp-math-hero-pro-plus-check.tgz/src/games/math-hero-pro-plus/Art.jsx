/** Home-page tile: a glowing space card with an equation to solve, a triangle's angles and gold stars. Plain SVG. */
export default function MathHeroProPlusArt() {
  return (
    <div className="art art-math-hero-pro-plus" aria-hidden="true" style={{ display: 'grid', placeItems: 'center', height: '100%' }}>
      <svg viewBox="0 0 160 110" width="100%" height="100%" style={{ maxHeight: 120 }}>
        <defs>
          <radialGradient id="mhpp-art-glow" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor="#2a1f4a" />
            <stop offset="100%" stopColor="#0B0F19" />
          </radialGradient>
        </defs>
        <rect x="6" y="4" width="148" height="102" rx="18" fill="url(#mhpp-art-glow)" stroke="#3b2a5c" strokeWidth="3" />
        {/* stars in the sky */}
        <circle cx="22" cy="18" r="1.4" fill="#fff" />
        <circle cx="140" cy="20" r="1.2" fill="#c4b5fd" />
        <circle cx="128" cy="94" r="1.3" fill="#fff" />
        {/* equation card */}
        <rect x="16" y="26" width="84" height="40" rx="10" fill="#111a2e" stroke="#facc15" strokeWidth="2" />
        <text x="58" y="53" textAnchor="middle" fontFamily="Baloo 2, sans-serif" fontWeight="800" fontSize="17" fill="#fde68a">3x + 5</text>
        {/* triangle with a missing angle */}
        <g transform="translate(108 30)">
          <polygon points="4,40 40,40 26,4" fill="rgba(56,189,248,0.15)" stroke="#7dd3fc" strokeWidth="2" strokeLinejoin="round" />
          <text x="26" y="34" textAnchor="middle" fontFamily="Baloo 2, sans-serif" fontWeight="800" fontSize="12" fill="#fcd34d">?</text>
        </g>
        {/* the "+" badge */}
        <circle cx="134" cy="24" r="9" fill="#facc15" />
        <path d="M134 19 V29 M129 24 H139" stroke="#0B0F19" strokeWidth="2.6" strokeLinecap="round" />
        {/* three gold stars */}
        {[40, 58, 76].map((x) => (
          <path
            key={x}
            transform={`translate(${x} 86)`}
            d="M0 -8 L2.4 -2.5 L8 -2.5 L3.5 1.2 L5.2 7 L0 3.6 L-5.2 7 L-3.5 1.2 L-8 -2.5 L-2.4 -2.5 Z"
            fill="#facc15"
            stroke="#fde68a"
            strokeWidth="1"
          />
        ))}
      </svg>
    </div>
  )
}
