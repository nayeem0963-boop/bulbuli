/** Home-page tile: a glowing space card with a times fact, a pie fraction and gold stars. Plain SVG. */
export default function MathHeroProArt() {
  return (
    <div className="art art-math-hero-pro" aria-hidden="true" style={{ display: 'grid', placeItems: 'center', height: '100%' }}>
      <svg viewBox="0 0 160 110" width="100%" height="100%" style={{ maxHeight: 120 }}>
        <defs>
          <radialGradient id="mhp-art-glow" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor="#1e2a4a" />
            <stop offset="100%" stopColor="#0B0F19" />
          </radialGradient>
        </defs>
        <rect x="6" y="4" width="148" height="102" rx="18" fill="url(#mhp-art-glow)" stroke="#1b2a49" strokeWidth="3" />
        {/* stars in the sky */}
        <circle cx="22" cy="20" r="1.4" fill="#fff" />
        <circle cx="138" cy="18" r="1.2" fill="#7dd3fc" />
        <circle cx="120" cy="92" r="1.3" fill="#fff" />
        {/* question card */}
        <rect x="20" y="28" width="76" height="40" rx="10" fill="#111a2e" stroke="#38bdf8" strokeWidth="2" />
        <text x="58" y="55" textAnchor="middle" fontFamily="Baloo 2, sans-serif" fontWeight="800" fontSize="19" fill="#fde68a">3 × 4</text>
        {/* pie: three quarters */}
        <g transform="translate(122 48)">
          <circle r="20" fill="#334155" />
          <path d="M0 0 L0 -20 A20 20 0 1 1 -20 0 Z" fill="#fb7185" stroke="#0B0F19" strokeWidth="2" />
          <path d="M0 -20 V20 M-20 0 H20" stroke="#0B0F19" strokeWidth="2" />
        </g>
        {/* three gold stars */}
        {[40, 58, 76].map((x) => (
          <path
            key={x}
            transform={`translate(${x} 86)`}
            d="M0 -8 L2.4 -2.5 L8 -2.5 L3.5 1.2 L5.2 7 L0 3.6 L-5.2 7 L-3.5 1.2 L-8 -2.5 L-2.4 -2.5 Z"
            fill="#facc15"
            stroke="#fde68a"
            strokeWidth="1"
          />
        ))}
      </svg>
    </div>
  )
}
