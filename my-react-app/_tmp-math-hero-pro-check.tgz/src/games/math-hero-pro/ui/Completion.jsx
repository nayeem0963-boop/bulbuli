import { ArrowRight, LayoutGrid, LockOpen, RotateCcw, Trophy, Zap } from 'lucide-react'
import { LEVELS, RESULT_HEADLINES } from '../engine.js'
import { Confetti, StarRow } from './Celebrate.jsx'
import { CARD, GHOST_BUTTON, GOLD_BUTTON } from './theme.js'

function Tile({ label, value, tone = 'text-white' }) {
  return (
    <div className="rounded-2xl border border-slate-700 bg-slate-800/60 px-4 py-3 text-center">
      <dt className="text-xs font-bold tracking-wider text-slate-400 uppercase">{label}</dt>
      <dd className={`m-0 mt-0.5 font-hero text-3xl font-extrabold ${tone}`}>{value}</dd>
    </div>
  )
}

export default function Completion({ level, result, language, text, n, onNext, onRetry, onLevels, headingRef }) {
  const { summary, xp, badgeNew, badgeOwned, unlockedNext, nextOpen, missed } = result
  const passed = summary.stars >= 1
  const nextLevel = LEVELS.find((l) => l.id === level.id + 1)
  const canGoNext = nextOpen && nextLevel

  return (
    <section aria-labelledby="mhp-results" className="relative z-10 mx-auto w-full max-w-3xl">
      <div className={`relative overflow-clip p-6 text-center @xl:p-8 ${CARD} border-2 border-amber-300/40 shadow-[0_0_60px_-20px_rgba(250,204,21,0.8)]`}>
        {passed && <Confetti count={summary.stars === 3 ? 110 : 70} />}

        <span className="mx-auto grid size-20 place-items-center rounded-full bg-gradient-to-br from-yellow-300 to-amber-500 text-[#0B0F19] shadow-[0_0_44px_-4px_rgba(250,204,21,0.85)] mhp-anim-pop">
          <Trophy size={40} strokeWidth={2.5} aria-hidden="true" focusable="false" />
        </span>
        <p className="m-0 mt-4 text-sm font-extrabold tracking-widest text-amber-200 uppercase">{level.title[language]}</p>
        <h2 id="mhp-results" ref={headingRef} tabIndex={-1} className="m-0 mt-1 font-hero text-3xl font-extrabold text-white outline-none @xl:text-4xl">
          {text.resultsTitle(n(level.id))}
        </h2>
        <p className="m-0 mt-2 text-lg text-slate-200">{RESULT_HEADLINES[summary.stars][language]}</p>

        <div className="mt-5 flex justify-center" role="img" aria-label={text.starsOf(n(summary.stars), n(3))}>
          <StarRow stars={summary.stars} size={56} animate />
        </div>

        <dl className="m-0 mt-6 grid grid-cols-3 gap-3">
          <Tile label={text.score} value={`${n(summary.correct)}/${n(summary.total)}`} />
          <Tile label={text.percent} value={`${n(summary.percent)}%`} tone="text-emerald-300" />
          <Tile label={text.xpGained} value={<span className="inline-flex items-center gap-1"><Zap size={22} strokeWidth={3} aria-hidden="true" focusable="false" />+{n(xp)}</span>} tone="text-yellow-300" />
        </dl>

        {/* the level's collectible badge */}
        <div
          className={`mx-auto mt-6 flex max-w-md items-center gap-4 rounded-2xl border-2 p-4 text-left ${
            badgeOwned ? 'border-amber-300/60 bg-amber-300/10 shadow-[0_0_30px_-12px_rgba(250,204,21,0.9)]' : 'border-slate-700 bg-slate-800/50'
          }`}
        >
          <span
            aria-hidden="true"
            className={`grid size-16 shrink-0 place-items-center rounded-2xl text-4xl ${badgeOwned ? `bg-slate-900 ring-2 ring-amber-300/70 ${badgeNew ? 'mhp-anim-badge' : ''}` : 'bg-slate-900 opacity-50 grayscale'}`}
          >
            {level.badge.emoji}
          </span>
          <div className="min-w-0">
            <p className={`m-0 text-xs font-extrabold tracking-widest uppercase ${badgeOwned ? 'text-amber-200' : 'text-slate-400'}`}>
              {badgeOwned ? (badgeNew ? text.badgeNew : text.badgeKept) : text.badgeLocked}
            </p>
            <p className={`m-0 font-hero text-2xl font-extrabold ${badgeOwned ? 'text-white' : 'text-slate-400'}`}>{level.badge.name[language]}</p>
          </div>
        </div>

        {unlockedNext && nextLevel && (
          <p className="mx-auto mt-4 inline-flex items-center gap-2 rounded-full bg-sky-400/15 px-4 py-1.5 text-sm font-extrabold text-sky-200 ring-1 ring-sky-400/40">
            <LockOpen size={16} strokeWidth={3} aria-hidden="true" focusable="false" />
            {text.unlocked(n(nextLevel.id))}
          </p>
        )}
        {passed && !nextLevel && <p className="m-0 mt-4 font-bold text-amber-200">{text.allDone}</p>}

        <div className="mt-6 flex flex-col-reverse gap-3 @md:flex-row @md:justify-center">
          <button type="button" onClick={onLevels} className={GHOST_BUTTON}>
            <LayoutGrid size={20} strokeWidth={2.75} aria-hidden="true" focusable="false" />
            {text.backToLevels}
          </button>
          <button type="button" onClick={onRetry} className={canGoNext ? GHOST_BUTTON : GOLD_BUTTON}>
            <RotateCcw size={20} strokeWidth={2.75} aria-hidden="true" focusable="false" />
            {text.tryAgain}
          </button>
          {canGoNext && (
            <button type="button" onClick={onNext} className={GOLD_BUTTON}>
              {text.playNext}
              <ArrowRight size={20} strokeWidth={3} aria-hidden="true" focusable="false" />
            </button>
          )}
        </div>
      </div>

      {missed.length > 0 && (
        <div className={`mt-4 p-5 ${CARD}`}>
          <h3 className="m-0 mb-3 font-hero text-lg font-extrabold text-white">{text.practise}</h3>
          <ul className="m-0 grid gap-2 p-0">
            {missed.map((q) => (
              <li key={q.id} className="flex list-none flex-wrap items-baseline justify-between gap-x-4 gap-y-1 rounded-xl bg-slate-800/60 px-4 py-2.5">
                <span className="text-sm text-slate-200">{n(q.equation ?? q.prompt[language])}</span>
                <span className="font-hero text-lg font-extrabold text-amber-200">{n(q.answer)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  )
}
