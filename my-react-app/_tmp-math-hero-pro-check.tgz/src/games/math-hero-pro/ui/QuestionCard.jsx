import { useEffect, useRef } from 'react'
import { ArrowLeft, ArrowRight, Check, Lightbulb, PartyPopper, Sparkles, X } from 'lucide-react'
import { correctSoFar, encouragement } from '../engine.js'
import { Confetti } from './Celebrate.jsx'
import { ACCENTS, CARD, GOLD_BUTTON } from './theme.js'
import Visual, { FractionText } from './Visuals.jsx'

const KEYS = ['1', '2', '3', '4']

function Progress({ round, level, text, n }) {
  const total = round.questions.length
  const done = round.responses.length
  const number = Math.min(round.index + 1, total)
  return (
    <div className="mb-4">
      <div className="mb-2 flex items-center justify-between gap-3 text-sm font-bold">
        <span className="text-slate-200">{text.questionOf(n(number), n(total))}</span>
        <span className="inline-flex items-center gap-1.5 text-emerald-300">
          <Check size={16} strokeWidth={3} aria-hidden="true" focusable="false" />
          {text.scoreLabel}: {n(correctSoFar(round))}
        </span>
      </div>
      <div
        role="progressbar"
        aria-label={text.questionOf(n(number), n(total))}
        aria-valuemin={0}
        aria-valuemax={total}
        aria-valuenow={done}
        className="h-3 overflow-hidden rounded-full bg-slate-800 ring-1 ring-slate-700"
      >
        <div
          className={`h-full rounded-full bg-gradient-to-r ${ACCENTS[level.accent].bar} shadow-[0_0_12px_rgba(255,255,255,0.35)] transition-[width] duration-500 ease-out`}
          style={{ width: `${(done / total) * 100}%` }}
        />
      </div>
      {/* one dot per question: green = right, rose = wrong, ringed = now */}
      <ol className="m-0 mt-2 flex gap-1.5 p-0" aria-hidden="true">
        {round.questions.map((q, i) => {
          const r = round.responses[i]
          return (
            <li
              key={q.id}
              className={`h-1.5 flex-1 list-none rounded-full transition-colors ${
                r ? (r.correct ? 'bg-emerald-400' : 'bg-rose-400') : i === round.index ? 'bg-amber-300/80' : 'bg-slate-700'
              }`}
            />
          )
        })}
      </ol>
    </div>
  )
}

function ChoiceButton({ value, index, state, disabled, onPick, n, isFraction }) {
  const styles = {
    idle: 'border-slate-600 bg-slate-800/80 text-white hover:-translate-y-0.5 hover:border-amber-300 hover:bg-slate-700/80 hover:shadow-[0_0_24px_-8px_rgba(250,204,21,0.8)] active:translate-y-0.5',
    right: 'border-emerald-400 bg-emerald-500/20 text-emerald-50 shadow-[0_0_30px_-6px_rgba(52,211,153,0.9)] mhp-anim-pop',
    wrong: 'border-rose-400 bg-rose-500/20 text-rose-50 mhp-anim-shake',
    dim: 'border-slate-700 bg-slate-800/40 text-slate-500',
  }[state]
  return (
    <button
      type="button"
      onClick={() => onPick(value)}
      disabled={disabled}
      aria-keyshortcuts={KEYS[index]}
      className={`relative flex min-h-20 w-full items-center justify-center rounded-2xl border-2 px-4 py-3 font-hero text-3xl font-extrabold transition duration-150 @xl:min-h-24 @xl:text-4xl ${styles} ${
        disabled ? 'cursor-default' : 'cursor-pointer'
      } focus-visible:outline-3 focus-visible:outline-offset-3 focus-visible:outline-yellow-200`}
    >
      <span className="absolute top-2 left-3 font-copy text-xs font-bold text-slate-400" aria-hidden="true">{n(KEYS[index])}</span>
      {isFraction ? <FractionText value={value} n={n} className="text-2xl @xl:text-3xl" /> : n(value)}
      {state === 'right' && <Check className="absolute top-2 right-2 text-emerald-300" size={22} strokeWidth={3} aria-hidden="true" focusable="false" />}
      {state === 'wrong' && <X className="absolute top-2 right-2 text-rose-300" size={22} strokeWidth={3} aria-hidden="true" focusable="false" />}
    </button>
  )
}

function Feedback({ correct, question, index, language, text, n, isLast, onContinue, continueRef }) {
  const cheer = encouragement(correct, index)[language]
  const Icon = correct ? PartyPopper : Lightbulb
  const answerText = question.answer.includes('/')
    ? `${n(question.answer)} (${text.fraction(...question.answer.split('/').map(n))})`
    : n(question.answer)
  return (
    <div
      className={`mt-5 rounded-2xl border-2 p-4 mhp-anim-rise @xl:p-5 ${
        correct ? 'border-emerald-400/60 bg-emerald-500/10' : 'border-amber-300/50 bg-amber-300/10'
      }`}
    >
      <div className="flex items-start gap-3">
        <span className={`grid size-11 shrink-0 place-items-center rounded-full ${correct ? 'bg-emerald-400 text-[#0B0F19]' : 'bg-amber-300 text-[#0B0F19]'}`}>
          <Icon size={22} strokeWidth={2.75} aria-hidden="true" focusable="false" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="m-0 font-hero text-xl font-extrabold text-white">
            {correct ? text.correctTitle : text.wrongTitle} <span className={correct ? 'text-emerald-200' : 'text-amber-200'}>{cheer}</span>
          </p>
          {!correct && (
            <p className="m-0 mt-1 text-base text-slate-100">
              {text.theAnswerIs}: <strong className="font-extrabold text-amber-200">{answerText}</strong>
            </p>
          )}
          <p className="m-0 mt-1.5 text-base text-slate-200">{n(question.explain[language])}</p>
          <p className="m-0 mt-3 flex items-start gap-2 rounded-xl bg-slate-900/70 px-3 py-2 text-sm text-sky-100 ring-1 ring-sky-400/30">
            <Sparkles size={16} strokeWidth={2.75} className="mt-0.5 shrink-0 text-sky-300" aria-hidden="true" focusable="false" />
            <span><strong className="font-extrabold text-sky-300">{text.tipLabel}:</strong> {n(question.tip[language])}</span>
          </p>
        </div>
      </div>
      <div className="mt-4 flex justify-end">
        <button type="button" ref={continueRef} onClick={onContinue} className={`${GOLD_BUTTON} w-full @md:w-auto`}>
          {isLast ? text.seeResults : text.nextQuestion}
          <ArrowRight size={20} strokeWidth={3} aria-hidden="true" focusable="false" />
        </button>
      </div>
    </div>
  )
}

export default function QuestionCard({ round, question, level, language, text, n, onAnswer, onContinue, onQuit, headingRef }) {
  const continueRef = useRef(null)
  const answered = round.phase === 'answered'
  const response = answered ? round.responses[round.responses.length - 1] : null
  const isFraction = question.choices.some((c) => c.includes('/'))

  // After answering, move focus to "Next", so Enter / Space carries on and screen readers hear the feedback.
  useEffect(() => {
    if (answered) continueRef.current?.focus({ preventScroll: true })
  }, [answered])

  const stateOf = (choice) => {
    if (!answered) return 'idle'
    if (choice === question.answer) return 'right'
    if (choice === response.choice) return 'wrong'
    return 'dim'
  }

  return (
    <section aria-labelledby="mhp-question" className="relative z-10 mx-auto w-full max-w-3xl">
      <div className="mb-3 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onQuit}
          aria-label={text.quitLabel}
          className="inline-flex min-h-11 cursor-pointer items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/70 px-3 text-sm font-bold text-slate-200 transition hover:border-slate-500 focus-visible:outline-3 focus-visible:outline-yellow-200"
        >
          <ArrowLeft size={16} strokeWidth={3} aria-hidden="true" focusable="false" />
          {text.quit}
        </button>
        <span className={`truncate rounded-full px-3 py-1 text-xs font-extrabold tracking-wide ring-1 ${ACCENTS[level.accent].chip}`}>
          {text.levelN(n(level.id))} · {level.title[language]}
        </span>
      </div>

      <div className={`relative overflow-clip p-5 @xl:p-7 ${CARD} border-2 ${ACCENTS[level.accent].ring} ${ACCENTS[level.accent].glow}`}>
        {answered && response.correct && <Confetti key={question.id} count={36} spread="burst" />}
        <Progress round={round} level={level} text={text} n={n} />

        <div key={question.id} className="mhp-anim-rise">
          <h2
            id="mhp-question"
            ref={headingRef}
            tabIndex={-1}
            className="m-0 text-center font-hero text-xl leading-snug font-extrabold text-white outline-none @xl:text-2xl"
          >
            {n(question.prompt[language])}
          </h2>
          {question.equation && (
            <p className="m-0 mt-3 text-center font-hero text-4xl font-extrabold tracking-wide text-amber-200 drop-shadow-[0_0_14px_rgba(252,211,77,0.45)] @xl:text-5xl">
              {n(question.equation)}
            </p>
          )}
          <div className="mt-3">
            <Visual visual={question.visual} n={n} />
          </div>

          <div role="group" aria-label={text.choicesLabel} className="mt-5 grid grid-cols-2 gap-3 @xl:gap-4">
            {question.choices.map((choice, i) => (
              <ChoiceButton
                key={choice}
                value={choice}
                index={i}
                state={stateOf(choice)}
                disabled={answered}
                onPick={onAnswer}
                n={n}
                isFraction={isFraction}
              />
            ))}
          </div>
        </div>

        <div aria-live="polite">
          {answered && (
            <Feedback
              correct={response.correct}
              question={question}
              index={round.index}
              language={language}
              text={text}
              n={n}
              isLast={round.index === round.questions.length - 1}
              onContinue={onContinue}
              continueRef={continueRef}
            />
          )}
        </div>
      </div>
      <p className="m-0 mt-3 hidden text-center text-xs text-slate-500 @3xl:block">{text.keyboardHint}</p>
    </section>
  )
}
